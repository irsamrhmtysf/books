# FOLIO / books

Private reading shelf for GitHub Pages.

Open `index.html` or visit `https://irsamrhmtysf.github.io/books/`.

## Layout

- `index.html` — shell
- `css/app.css` — paper, night, sepia
- `js/catalog.js` — seed collection (Range)
- `js/store.js` — local persistence
- `js/app.js` — screens and actions
- `data/range.json` — source notes for the first book

Nothing is uploaded. Progress, notes, recall grades, and books you add stay in this browser. Export from You if you want a backup.

Range is the first book. The companion is original recall notes, not the book text.
